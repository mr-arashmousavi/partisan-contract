import BN from "bn.js";
import { Cell, beginCell, Address, toNano } from "ton";

const OFFCHAIN_CONTENT_PREFIX = 0x01;

function serializeUri(uri : any){
  return new TextEncoder().encode(encodeURI(uri));
}

export function data(): Cell {

  const cell = new Cell();

  cell.bits.writeAddress(Address.parseFriendly("EQABiTxle7aANcUhZ8DsNIKyS0nNOevjXK9nL-LUjeACgw1L").address);
  cell.bits.writeUint(0, 64);  // next_item_index
  cell.bits.writeUint(0, 32);  // counter
  cell.bits.writeUint(1, 256);  // ID
  cell.bits.writeUint(0, 64);  // price 
  const emptyCell = new Cell();
  cell.refs[0] = emptyCell

  return cell;

}

export function changePrice(price : number): Cell {
  return beginCell()
      .storeUint(2, 32)
      .storeUint(0, 64)
      .storeUint(toNano(price), 64)
      .endCell();
}

export function buy(amout: number): Cell { 
  return beginCell()
      .storeUint(1, 32)
      .storeUint(0, 64)
      .storeUint(123456789, 256)
      .storeUint(amout, 64)
      .endCell();
} 