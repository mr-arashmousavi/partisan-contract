import BN from "bn.js";
import { Cell, beginCell, Address, toNano } from "ton";

const OFFCHAIN_CONTENT_PREFIX = 0x01;

function serializeUri(uri : any){
  return new TextEncoder().encode(encodeURI(uri));
}

export function data(): Cell {
  const cell = new Cell();
  cell.bits.writeAddress(Address.parseFriendly("EQABiTxle7aANcUhZ8DsNIKyS0nNOevjXK9nL-LUjeACgw1L").address);
  cell.bits.writeUint(0, 64); // next_item_index
  cell.bits.writeUint(0, 64); // nft_price
  cell.bits.writeUint(0, 2);// sale status
  cell.bits.writeUint(0, 64); // max sale 
  cell.bits.writeUint(0, 64); //ref price
  return cell;
}

export function changeData(price : number, sale_status : number, max_sale : number, ref_price : number): Cell{
  const cell = new Cell();
  cell.bits.writeUint(103, 32); // op
  cell.bits.writeUint(0, 64); // query_id
  cell.bits.writeUint(price, 64); // nft_price
  cell.bits.writeUint(sale_status, 2);// sale status
  cell.bits.writeUint(max_sale, 64); // max sale 
  cell.bits.writeUint(ref_price, 64); //ref price
  return cell;
}

export function buyItem(): Cell{
  const cell = new Cell();
  cell.bits.writeUint(0, 32); // op
  cell.bits.writeUint(0, 64); // query_id
  return cell;
}

export function buyItemWithRefferal(ref_address : Address): Cell{
  const cell = new Cell();
  cell.bits.writeUint(2, 32); // op
  cell.bits.writeUint(0, 64); // query_id
  cell.bits.writeAddress(ref_address);
  return cell;
}

export function withdraw(amount : number): Cell{
  const cell = new Cell();
  cell.bits.writeUint(102, 32); // op
  cell.bits.writeUint(0, 64); // query_id
  cell.bits.writeUint(amount, 64);
  return cell;
}