"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mint = exports.data = void 0;
const ton_1 = require("ton");
const NFT_ITEM_CODE_HEX = 'B5EE9C7241020B0100019C000114FF00F4A413F4BCF2C80B0102016202030202CE04050009A11F9FE0030201200607001D403C8CB3F58CF1601CF16CCC9ED54802A30C8871C02497C0F83434C0C05C6C2497C0F83E900C3C00412CE3844C0C8D1480B1C17CB865407E90350C3C00B80174C7F4CFE08417F30F45148C2EB8C08C0D0D4D60840BF2C9A8852EB8C097C12103FCBC200809003B3B513434CFFE900835D27080269FC07E90350C04090408F80C1C165B5B6001FC3210365E22015124C705F2E19101FA40FA40D20031FA00820AFAF0801AA121A120C200F2E192218E3E821005138D91C85008CF16500ACF1671244814544690708010C8CB055007CF165005FA0215CB6A12CB1FCB3F226EB39458CF17019132E201C901FB001036941029365BE226D70B01C3009410266C31E30D5502F0020A00767082108B77173504C8CBFF5005CF16102410238040708010C8CB055007CF165005FA0215CB6A12CB1FCB3F226EB39458CF17019132E201C901FB0000648210D53276DB103744046D71708010C8CB055007CF165005FA0215CB6A12CB1FCB3F226EB39458CF17019132E201C901FB00D5B62154';
const OFFCHAIN_CONTENT_PREFIX = 0x01;
function serializeUri(uri) {
    return new TextEncoder().encode(encodeURI(uri));
}
function createOffchainUriCell(uri) {
    const cell = new ton_1.Cell();
    cell.bits.writeUint(OFFCHAIN_CONTENT_PREFIX, 8);
    cell.bits.writeBuffer(Buffer.from(serializeUri(uri)));
    return cell;
}
function createContentCell(params) {
    const collectionContentCell = createOffchainUriCell(params.collectionContentUri);
    const commonContentCell = new ton_1.Cell();
    commonContentCell.bits.writeBuffer(Buffer.from(serializeUri(params.nftItemContentBaseUri)));
    const contentCell = new ton_1.Cell();
    contentCell.refs[0] = collectionContentCell;
    contentCell.refs[1] = commonContentCell;
    return contentCell;
}
function createRoyaltyCell(params) {
    const royaltyCell = new ton_1.Cell();
    royaltyCell.bits.writeUint(params.royaltyFactor, 16);
    royaltyCell.bits.writeUint(params.royaltyBase, 16);
    royaltyCell.bits.writeAddress(params.royaltyAddress);
    return royaltyCell;
}
function createMintBody(params) {
    const body = new ton_1.Cell();
    body.bits.writeUint(1, 32); // OP deploy new nft
    body.bits.writeUint(params.queryId || 0, 64); // query_id
    // body.bits.writeUint(params.itemIndex, 64);
    // body.bits.writeCoins(params.amount);
    const nftItemContent = new ton_1.Cell();
    nftItemContent.bits.writeAddress(params.itemOwnerAddress);
    const uriContent = new ton_1.Cell();
    uriContent.bits.writeBuffer(Buffer.from(params.itemContentUri));
    nftItemContent.refs[0] = uriContent;
    body.refs[0] = nftItemContent;
    return body;
}
// encode contract storage according to save_data() contract method
function data() {
    // return beginCell()
    //     .storeAddress(Address.parseFriendly("EQABiTxle7aANcUhZ8DsNIKyS0nNOevjXK9nL-LUjeACgw1L").address)
    //     .storeUint(0, 64)
    //     .storeRef(new Cell())
    //     .storeRef(Cell.fromBoc(NFT_ITEM_CODE_HEX)[0])
    //     .storeRef(new Cell())
    //     .endCell();
    let options = {
        ownerAddress: ton_1.Address.parseFriendly("EQABiTxle7aANcUhZ8DsNIKyS0nNOevjXK9nL-LUjeACgw1L").address,
        royalty: 0.05,
        royaltyAddress: ton_1.Address.parseFriendly("EQABiTxle7aANcUhZ8DsNIKyS0nNOevjXK9nL-LUjeACgw1L").address,
        collectionContentUri: 'https://tonpartisan.com/uploads/collection.json',
        nftItemContentBaseUri: 'https://tonpartisan.com/uploads/',
        nftItemCodeHex: ton_1.Cell.fromBoc(NFT_ITEM_CODE_HEX)[0],
        royaltyBase: 1000,
        royaltyFactor: 0
    };
    options.royaltyFactor = Math.floor(options.royalty * options.royaltyBase);
    const cell = new ton_1.Cell();
    cell.bits.writeAddress(options.ownerAddress);
    cell.bits.writeUint(0, 64);
    cell.refs[0] = createContentCell(options);
    cell.refs[1] = options.nftItemCodeHex;
    cell.refs[2] = createRoyaltyCell(options);
    return cell;
}
exports.data = data;
function mint() {
    return createMintBody({
        amount: (0, ton_1.toNano)(0.05),
        itemIndex: 0,
        itemOwnerAddress: ton_1.Address.parseFriendly("EQABiTxle7aANcUhZ8DsNIKyS0nNOevjXK9nL-LUjeACgw1L").address,
        itemContentUri: '1.json'
    });
}
exports.mint = mint;
