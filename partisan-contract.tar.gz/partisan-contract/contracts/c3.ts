import BN from "bn.js";
import { Cell, beginCell, Address } from "ton";

// encode contract storage according to save_data() contract method
export function data(): Cell {
  return beginCell()
      .storeAddress(Address.parseFriendly("EQABiTxle7aANcUhZ8DsNIKyS0nNOevjXK9nL-LUjeACgw1L").address)
      .storeUint(0, 64)
      .storeUint(0, 64)
      .endCell();
}

export function changePrice(price: number | BN): Cell {
  return beginCell()
      .storeInt(1, 32)
      .storeUint(0, 64)
      .storeInt(price, 64)
      .endCell();
}

export function withdraw(price: number | BN): Cell {
  return beginCell()
      .storeInt(2, 32)
      .storeUint(0, 64)
      .storeInt(price, 64)
      .endCell();
}

export function addCount(price: number | BN): Cell {
  return beginCell()
      .storeInt(0, 32)
      .storeUint(0, 64)
      .storeCoins(price)
      .endCell();
}