"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.increment = exports.data = void 0;
const ton_1 = require("ton");
// encode contract storage according to save_data() contract method
function data() {
    return (0, ton_1.beginCell)().storeUint(0, 64).endCell();
}
exports.data = data;
function increment() {
    return (0, ton_1.beginCell)().storeUint(0, 64).endCell();
}
exports.increment = increment;
