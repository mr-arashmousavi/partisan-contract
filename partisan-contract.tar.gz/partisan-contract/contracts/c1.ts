import BN from "bn.js";
import { Cell, beginCell, Address } from "ton";

// encode contract storage according to save_data() contract method
export function data(): Cell {
  return beginCell().storeUint(0, 64).endCell();
}

export function increment(): Cell {
  return beginCell().storeUint(1, 32).storeUint(0, 64).endCell();
}