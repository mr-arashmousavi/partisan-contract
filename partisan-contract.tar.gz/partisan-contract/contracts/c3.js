"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.addCount = exports.withdraw = exports.changePrice = exports.data = void 0;
const ton_1 = require("ton");
// encode contract storage according to save_data() contract method
function data() {
    return (0, ton_1.beginCell)()
        .storeAddress(ton_1.Address.parseFriendly("EQABiTxle7aANcUhZ8DsNIKyS0nNOevjXK9nL-LUjeACgw1L").address)
        .storeUint(0, 64)
        .storeUint(0, 64)
        .endCell();
}
exports.data = data;
function changePrice(price) {
    return (0, ton_1.beginCell)()
        .storeInt(1, 32)
        .storeUint(0, 64)
        .storeInt(price, 64)
        .endCell();
}
exports.changePrice = changePrice;
function withdraw(price) {
    return (0, ton_1.beginCell)()
        .storeInt(2, 32)
        .storeUint(0, 64)
        .storeInt(price, 64)
        .endCell();
}
exports.withdraw = withdraw;
function addCount(price) {
    return (0, ton_1.beginCell)()
        .storeInt(0, 32)
        .storeUint(0, 64)
        .storeCoins(price)
        .endCell();
}
exports.addCount = addCount;
