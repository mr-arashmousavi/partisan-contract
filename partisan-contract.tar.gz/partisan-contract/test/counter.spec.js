"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.prototype.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const chai_1 = __importStar(require("chai"));
const chai_bn_1 = __importDefault(require("chai-bn"));
const bn_js_1 = __importDefault(require("bn.js"));
chai_1.default.use((0, chai_bn_1.default)(bn_js_1.default));
const ton_1 = require("ton");
const ton_contract_executor_1 = require("ton-contract-executor");
const main = __importStar(require("../contracts/main"));
const helpers_1 = require("./helpers");
const main_compiled_json_1 = require("../build/main.compiled.json");
describe("Counter tests", () => {
    let contract;
    beforeEach(() => __awaiter(void 0, void 0, void 0, function* () {
        contract = yield ton_contract_executor_1.SmartContract.fromCell(ton_1.Cell.fromBoc(main_compiled_json_1.hex)[0], // code cell from build output
        main.data({
            ownerAddress: (0, helpers_1.randomAddress)("owner"),
            counter: 17,
        }));
    }));
    it("should get the meaning of life", () => __awaiter(void 0, void 0, void 0, function* () {
        const call = yield contract.invokeGetMethod("meaning_of_life", []);
        (0, chai_1.expect)(call.result[0]).to.be.bignumber.equal(new bn_js_1.default(42));
    }));
    it("should get counter value and increment it", () => __awaiter(void 0, void 0, void 0, function* () {
        const call = yield contract.invokeGetMethod("counter", []);
        (0, chai_1.expect)(call.result[0]).to.be.bignumber.equal(new bn_js_1.default(17));
        const send = yield contract.sendInternalMessage((0, helpers_1.internalMessage)({
            from: (0, helpers_1.randomAddress)("notowner"),
            body: main.increment(),
        }));
        (0, chai_1.expect)(send.type).to.equal("success");
        const call2 = yield contract.invokeGetMethod("counter", []);
        (0, chai_1.expect)(call2.result[0]).to.be.bignumber.equal(new bn_js_1.default(18));
    }));
});
