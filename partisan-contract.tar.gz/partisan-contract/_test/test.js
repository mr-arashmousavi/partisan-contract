import { TonClient, WalletContract, WalletV3R2Source, contractAddress, SendMode } from "ton";
import { Address, Cell, CellMessage, CommonMessageInfo, fromNano, InternalMessage, StateInit, toNano } from "ton";
import { mnemonicNew, mnemonicToWalletKey } from "ton-crypto";

const tester_mnemonic = process.env.TESTER_MNEMONIC ?? "";

async function _run(){

    const client = new TonClient({ endpoint: `https://toncenter.com/api/v2/jsonRPC` });

    const walletKey = await mnemonicToWalletKey(tester_mnemonic.split(" "));
    const walletContract = WalletContract.create(client, WalletV3R2Source.create({ publicKey: walletKey.publicKey, workchain : 0 }));
    console.log(` - Wallet tester address : ${walletContract.address.toFriendly()}`);
    const walletBalance = await client.getBalance(walletContract.address);
    console.log("wallet balance : ", fromNano(walletBalance));

    const cAddress = Address.parseFriendly("EQAA1yvDaDwEK5vHGOXRdtS2MbOVd1-TNy01L1S_t2HF4oLu").address;

    const call1 = await walletContract.client.callGetMethod(cAddress, "get_collection_data");

    console.log(call1);

}


  