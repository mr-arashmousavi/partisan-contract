ton3 = require('ton3');
const {Address} = require('ton');
const { default: TonWeb } = require('tonweb');
const tonWeb = require('tonweb');

let msg_data = "te6ccuEBAQEADgAcABgAAAAAAAAAAAAAAABsU7h3";

let in_msg_body = ton3.BOC.fromStandard(msg_data).slice();
let op = in_msg_body.loadInt(32);
let query_id = in_msg_body.loadInt(64);

console.log("op : ", op);
console.log("query_id : ", query_id);
// (async()=>{

//     const tonweb = new TonWeb()
//     let domain = await tonweb.dns.getWalletAddress('tonpartisan.ton');

//     console.log(">>> domain ", domain)
// })()

// console.log(">>> ", Address.parseRaw('0:3d3fca6e3127d098b1adbce3d14da928d91f4167d984e6f46c5cb159bd6166da').toFriendly().toString())
console.log(">>> ", Address.parseFriendly('EQA9P8puMSfQmLGtvOPRTako2R9BZ9mE5vRsXLFZvWFm2nGB').address.toString())
if(op == 6){
    let mint_status = in_msg_body.loadUint(2);
    console.log("min_status : ", mint_status);
}